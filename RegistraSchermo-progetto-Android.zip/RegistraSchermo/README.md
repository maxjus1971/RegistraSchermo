# RegistraSchermo — Android 10+

Prototipo Android nativo, in Java, senza SDK o librerie di registrazione esterne.
Registra **il video dello schermo e l'audio interno delle applicazioni** in un
unico file MP4 (H.264 + AAC). **Non registra il microfono**.

## Requisiti
- Android 10 (API 29) o successivo; progettato per Android 13 e successivi.
- Android Studio con Android SDK 35 e JDK 17+.
- Connessione Internet sul PC per il primo download di Gradle e del plugin Android.

## Aprire e ottenere l'APK
1. Android Studio > **Open** > scegliere la cartella `RegistraSchermo`.
2. Android Studio importa il progetto e sincronizza Gradle.
3. **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. L'APK debug viene generato in `app/build/outputs/apk/debug/app-debug.apk`.
5. Copiare l'APK sul telefono e installarlo, autorizzando l'origine se richiesto.

### Alternativa: compilare tramite GitHub Actions
Il progetto include `.github/workflows/build-apk.yml`. Se lo carichi in un
repository GitHub, apri **Actions > Compila APK Android > Run workflow**.
Quando la build termina, in **Artifacts** trovi `RegistraSchermo-APK`.
È una procedura da provare; non è stata eseguita qui.

Nota: lo ZIP non include un APK precompilato. Non è stato possibile compilare in
questo ambiente privo di Android SDK/Gradle. Il progetto non è stato testato
fisicamente su dispositivo: considerarlo **versione 0.1 di prova**.

## Utilizzo
1. Aprire l'app e premere **Avvia registrazione**.
2. Concedere il permesso audio: Android lo richiede anche per la cattura
   dell'audio interno, ma **questa app non usa il microfono**.
3. Concedere facoltativamente le notifiche, per il pulsante "Ferma e salva".
4. Nella finestra di Android autorizzare la cattura schermo.
   Se disponibile la scelta, preferire **schermo intero**.
5. Passare all'app da registrare. Per terminare, tornare a RegistraSchermo
   oppure usare **Ferma e salva** nella notifica.
6. Il file MP4 si trova in **Filmati/RegistraSchermo**.

## Limiti della prima versione
- Alcune app proibiscono l'acquisizione dell'audio: il file può essere muto
  anche se il video è registrato correttamente.
- Streaming protetto, schermate sensibili e contenuti DRM possono apparire neri.
- Evitare di ruotare il dispositivo durante una registrazione: la v1 usa una
  dimensione video fissa determinata all'avvio.
- Nessun tasto Pausa, nessun editing; solo **Avvia** e **Ferma e salva**.
- La notifica può non comparire se il permesso notifiche è negato su Android 13+;
  il tasto Stop nell'app rimane disponibile.
- Alcuni dispositivi possono richiedere compatibilità specifica per i codec.

## Componenti di sistema
- `MediaProjection`: video dello schermo con consenso esplicito.
- `AudioPlaybackCaptureConfiguration` + `AudioRecord`: solo audio riprodotto.
- `MediaCodec`: codifica video AVC e audio AAC.
- `MediaMuxer`: multiplexing MP4.
- `MediaStore`: salvataggio in Filmati senza permessi storage legacy.
- Foreground Service `mediaProjection` e notifica persistente.

## Sicurezza e privacy
Nessun accesso Internet richiesto; non vengono inviati dati. Ogni nuova
registrazione richiede il consenso di Android. Il permesso `RECORD_AUDIO` è
necessario all'API interna anche senza catturare il microfono.
